<? include("header.php") ?>

<div class="container main">
    <div class="row">
        <div class="col-sm-12">

		</div>
	</div>
</div>

<? include("footer.php") ?>

