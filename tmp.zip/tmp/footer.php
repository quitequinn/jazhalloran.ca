
   </div><!-- #content -->

   <footer id="colophon" class="site-footer" role="contentinfo">
   
   </footer><!-- #colophon -->
</div><!-- #page -->


<!-- CDN Dependencies -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<!-- <script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/jquery-ui.min.js"></script>
<link rel="stylesheet" href="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/jquery-ui.min.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css"> -->

<!-- Local Dependencies -->
<!-- Typography -->
<!-- <script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/jQuery-widowFix/js/jquery.widowFix-1.3.2.min.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/bg-loaded.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/modernizer.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/smartquotes/smartquotes.min.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/hypher/jquery.hypher.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/hypher/en-us.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/bootstrap/bootstrap-3.3.4.min.js"></script> -->
<script src="//cdnjs.cloudflare.com/ajax/libs/underscore.js/1.6.0/underscore-min.js"></script>
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/src/static/js/gyro/gyro.min.js"></script>

<!-- <link rel="stylesheet" href="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/fonts/font.css"/> -->
<!-- <link rel="stylesheet" href="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/fonts/font-big.css"/>
 -->
<!-- MAIN JS -->
<script src="<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/dist/js/main.js"></script>

</body>
</html>
