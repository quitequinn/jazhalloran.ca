<? include("header.php") ?>

<p>It's a 404...</p>

<? include("footer.php") ?>

